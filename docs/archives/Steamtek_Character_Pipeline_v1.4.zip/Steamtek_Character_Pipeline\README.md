# Steamtek Reusable Character Pipeline

This package establishes the reusable Blender-to-Godot character pipeline while keeping `Steamtek_C001` as an immutable golden reference.

## Start here

1. Read `docs/Steamtek_Character_Pipeline.md`.
2. Open `blender/Steamtek_Character_Master.blend` in Blender 4.5 LTS.
3. Replace only the character mesh, calibrated armature, materials, and equipment slots.
4. Run `blender/scripts/Steamtek_Validate_CharacterScene.py` before rendering.
5. Render with `blender/scripts/Steamtek_Render_8Directions.py`.
6. Build fixed 256 x 256 production frames with `tools/Steamtek_Build_ProductionFrames.py`.
7. Import the production frames with `godot/Steamtek_Import_CharacterFrames.gd`.

The v1.4 kit contains the production-approved `Steamtek_HumanRig_v1`, generated from Blender 4.5 LTS's bundled Rigify human metarig because no authoritative C001 rig was found. The included `STK_CalibrationDummy_v1` exercises the real deform rig, `STK_IDLE`, `STK_WALK`, all eight genuine directions, raw-render QA, and production-frame QA. Two real Godot comparisons calibrated and then approved the result: `south` faces the camera, the production front-frame envelope matches C001 at pixels 18 through 238, and both characters measured the same runtime vertical bounds of 143 through 461.

The Blender source folders contain `.gdignore` markers. Godot consumes the rendered PNG assets and must not import the `.blend` files directly; if Godot displays its Blender-path prompt for an already-open project, choose **Disable '.blend' Import**.

## Locked contract

- 1254 x 1254 RGBA authoritative source-render canvas
- 256 x 256 fixed Godot production canvas, uniformly resized with no crop
- transparent background
- orthographic 2:1 dimetric camera
- eight genuine rotations, never mirrored
- ground-contact root at world origin, centered between the boots
- Godot visual scale `0.73`
- Godot visual offset `(0, -110)`
- collision footprint `28 x 18`
- fixed canvas; no per-frame cropping or recentering
