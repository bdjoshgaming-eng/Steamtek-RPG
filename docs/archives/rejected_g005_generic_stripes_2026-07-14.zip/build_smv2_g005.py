"""Build the staging-only G005 worn industrial guide-stripe street tile."""

from __future__ import annotations

import sys
from pathlib import Path

import bpy

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_smv2_g001 import add_irregular_surface, build_ground, configure_scene
from build_smv2_w003 import clear_scene
from steamtek_render_standard import weathered_material


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ASSET_NAME = "SMV2_G005_WornGuideStripe"
BLEND_PATH = PROJECT_ROOT / f"blender/modular_v2/{ASSET_NAME}.blend"
RENDER_PATH = PROJECT_ROOT / (
    "assets/modular_v2/ground/source/blender_renders/"
    f"{ASSET_NAME}_blender_raw.png"
)


def add_worn_stripe_segment(name, x_center, y_start, y_end, width, material):
    half_width = width * 0.5
    half_length = (y_end - y_start) * 0.5
    center = (x_center, (y_start + y_end) * 0.5)
    points = (
        (-half_width * 0.92, -half_length),
        (half_width, -half_length + 0.015),
        (half_width * 0.88, half_length),
        (-half_width, half_length - 0.018),
    )
    add_irregular_surface(name, center, points, material, z=0.004)


def build_g005():
    # Reuse the accepted G001 rain-darkened concrete without modifying it.
    build_ground("base")

    paint = weathered_material(
        "STK_WornSafetyOchrePaint",
        (0.105, 0.066, 0.018, 1.0),
        (0.42, 0.265, 0.055, 1.0),
        0.0,
        0.54,
    )
    nodes = paint.node_tree.nodes
    wear = nodes.get("BroadSurfaceWear")
    if wear is not None:
        wear.inputs["Scale"].default_value = 18.0
        wear.inputs["Detail"].default_value = 5.0
        wear.inputs["Roughness"].default_value = 0.72
        wear.inputs["Distortion"].default_value = 0.16

    # Two restrained maintenance-lane rails cross opposite tile edges. Small
    # gaps make the old paint feel worn while keeping the role repeatable.
    segments = (
        (-0.34, -2.00, -1.12, 0.135),
        (-0.34, -0.94, -0.18, 0.125),
        (-0.34, 0.04, 0.88, 0.132),
        (-0.34, 1.08, 2.00, 0.128),
        (0.34, -2.00, -1.28, 0.128),
        (0.34, -1.08, -0.22, 0.135),
        (0.34, -0.02, 0.72, 0.122),
        (0.34, 0.94, 2.00, 0.134),
    )
    for index, (x_center, y_start, y_end, width) in enumerate(segments, start=1):
        add_worn_stripe_segment(
            f"GuideStripe_{index:02d}", x_center, y_start, y_end, width, paint
        )


def main():
    BLEND_PATH.parent.mkdir(parents=True, exist_ok=True)
    RENDER_PATH.parent.mkdir(parents=True, exist_ok=True)
    clear_scene()
    build_g005()
    configure_scene(RENDER_PATH)
    bpy.ops.wm.save_as_mainfile(filepath=str(BLEND_PATH))
    bpy.ops.render.render(write_still=True)
    print(f"Saved blend: {BLEND_PATH}")
    print(f"Rendered PNG: {RENDER_PATH}")


if __name__ == "__main__":
    main()
