"""Validate the generated Steamtek 60/30 camera calibration without third-party packages."""

from __future__ import annotations

import argparse
import json
import struct
import sys
from pathlib import Path


PROFILE = "environment_fixed_off_axis_60_v2"
EXPECTED_FRONT = (313.534, -90.509)
EXPECTED_SIDE = (-181.020, -156.768)
TOLERANCE = 0.05


def arguments():
    argv = sys.argv
    argv = argv[argv.index("--") + 1 :] if "--" in argv else argv[1:]
    parser = argparse.ArgumentParser()
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--image", required=True)
    return parser.parse_args(argv)


def close_pair(measured, expected):
    return all(abs(float(measured[i]) - expected[i]) <= TOLERANCE for i in range(2))


def png_header(path: Path):
    with path.open("rb") as stream:
        signature = stream.read(8)
        if signature != b"\x89PNG\r\n\x1a\n":
            raise ValueError("Output is not a PNG file")
        length = struct.unpack(">I", stream.read(4))[0]
        kind = stream.read(4)
        if kind != b"IHDR" or length != 13:
            raise ValueError("PNG is missing its IHDR header")
        width, height, bit_depth, color_type, _, _, _ = struct.unpack(">IIBBBBB", stream.read(13))
    return width, height, bit_depth, color_type


def main():
    args = arguments()
    metadata_path = Path(args.metadata).resolve()
    image_path = Path(args.image).resolve()
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    width, height, bit_depth, color_type = png_header(image_path)

    checks = {
        "profile": metadata.get("profile") == PROFILE,
        "orthographic": metadata.get("camera_type") == "ORTHOGRAPHIC",
        "angles": (
            metadata.get("azimuth_degrees") == 60.0
            and metadata.get("elevation_degrees") == 30.0
            and metadata.get("roll_degrees") == 0.0
        ),
        "fixed_runtime_camera": metadata.get("runtime_camera_rotation") is False,
        "front_basis_raw_godot_pixels": close_pair(
            metadata["measured_pixels"]["front_godot_delta_y_down"], EXPECTED_FRONT
        ),
        "side_basis_raw_godot_pixels": close_pair(
            metadata["measured_pixels"]["side_godot_delta_y_down"], EXPECTED_SIDE
        ),
        "builder_validation": metadata.get("contract_validation", {}).get("passed") is True,
        "png_dimensions": [width, height] == metadata.get("render_size"),
        "png_rgba": color_type == 6 and bit_depth == 8,
    }

    for name, passed in checks.items():
        print(f"{'PASS' if passed else 'FAIL'} {name}")
    passed = all(checks.values())
    print("STEAMTEK_CAMERA_CALIBRATION_PASS" if passed else "STEAMTEK_CAMERA_CALIBRATION_FAIL")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
