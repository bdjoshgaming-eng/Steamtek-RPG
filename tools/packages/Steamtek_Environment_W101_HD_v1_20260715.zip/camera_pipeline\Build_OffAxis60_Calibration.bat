@echo off
setlocal
set "ROOT=%~dp0"
set "BLENDER_EXE=C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"

if not exist "%BLENDER_EXE%" (
  echo Blender was not found at:
  echo %BLENDER_EXE%
  echo.
  echo Edit BLENDER_EXE in this file for this PC, then run it again.
  pause
  exit /b 1
)

if not exist "%ROOT%output" mkdir "%ROOT%output"
if not exist "%ROOT%blender\master" mkdir "%ROOT%blender\master"

"%BLENDER_EXE%" --background --factory-startup --python "%ROOT%blender\build_offaxis60_calibration.py" -- --output "%ROOT%output\Steamtek_OffAxis60_Calibration.png" --blend "%ROOT%blender\master\Steamtek_OffAxis60_Calibration.blend" --size 1280
if errorlevel 1 (
  echo Calibration build failed.
  pause
  exit /b 1
)

echo.
echo Steamtek off-axis 60-degree calibration completed.
echo Output: %ROOT%output\Steamtek_OffAxis60_Calibration.png
echo.
echo Validating camera contract...
"%BLENDER_EXE%" --background --factory-startup --python "%ROOT%tools\validate_offaxis60_calibration.py" -- --metadata "%ROOT%output\Steamtek_OffAxis60_Calibration.json" --image "%ROOT%output\Steamtek_OffAxis60_Calibration.png"
if errorlevel 1 (
  echo Calibration rendered, but validation failed. Do not use it for production.
  pause
  exit /b 1
)
pause
