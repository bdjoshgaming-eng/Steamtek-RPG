# Steamtek Locked Camera Pipeline

This package is the authoritative Blender calibration kit for Steamtek's fixed
environment camera.

## Start here

1. Run `Build_OffAxis60_Calibration.bat`.
2. Confirm the validator ends with `STEAMTEK_CAMERA_CALIBRATION_PASS`.
3. Open `blender/master/Steamtek_OffAxis60_Calibration.blend` to inspect the
   locked camera and asymmetric projection proof.
4. Read `docs/STEAMTEK_OFFAXIS60_CAMERA_PIPELINE.md` before creating production
   assets.

## Locked production profile

- Profile: `environment_fixed_off_axis_60_v2`
- Camera: orthographic
- Azimuth: 60 degrees
- Elevation: 30 degrees
- Roll: 0 degrees
- Runtime rotation: disabled
- Front construction axis: world `+X`
- Side construction axis: world `-Y`

The older 45-degree C001 character camera remains a separate legacy profile and
is not modified by this package.
