import bpy


MODULE = "steamtek_humanoid_intake"


try:
    bpy.ops.preferences.addon_enable(module=MODULE)
    bpy.ops.wm.save_userpref()
    print(f"STEAMTEK_INSTALL_OK: enabled {MODULE}")
except Exception as exc:
    print(f"STEAMTEK_INSTALL_ERROR: {exc}")
    raise
