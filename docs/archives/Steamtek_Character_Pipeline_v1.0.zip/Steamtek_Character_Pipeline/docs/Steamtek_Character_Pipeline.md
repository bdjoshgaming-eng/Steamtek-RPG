# Steamtek Character Pipeline v1.0

## Authority

`Steamtek_C001` is the immutable golden reference. `Steamtek_Character_Master.blend` is reusable infrastructure, not C001. Never save new character work over either file.

## Master scene

The master contains the locked camera, render settings, lighting collections, direction root, ground-contact root, character/equipment slots, reference metadata, and an intentionally empty `Armature` object. The armature has the custom property `steamtek_placeholder = true`; production validation must fail until it is replaced by the real compatible humanoid rig.

The hierarchy is:

```text
ROOT_Direction
└── ROOT_GroundContact
    ├── Armature (empty calibration slot)
    ├── Character_Mesh_SLOT
    └── Equipment_SLOT
```

The ground-contact and direction roots remain at the world origin. Fit the character so the point centered between both boot contacts is `(0, 0, 0)`. The character faces Blender `-Y` at the south/zero-degree orientation.

## Character setup

1. Duplicate `Steamtek_Character_Master.blend` to a character-specific file.
2. Install the approved humanoid armature without moving the roots, camera, or render rig.
3. Set `Armature["steamtek_placeholder"]` to `false` only after calibration against C001.
4. Parent mesh and equipment beneath `ROOT_GroundContact` (normally through the armature).
5. Assign one of the shared actions named in the character manifest.
6. Keep every frame on the fixed 1254 x 1254 canvas. Do not crop or recenter renders.

## Scene validation

From Blender's Scripting workspace, run:

```text
Steamtek_Validate_CharacterScene.py -- --manifest <manifest.json> --production
```

Omit `--production` only while checking the uncalibrated master itself.

## Eight-direction render

Run Blender in the background or from its Scripting workspace:

```text
blender -b Character.blend --python-exit-code 1 --python Steamtek_Render_8Directions.py -- \
  --manifest Steamtek_Character_Manifest.json \
  --character-id Steamtek_C002 \
  --animation walk \
  --output renders \
  --production
```

The renderer does not repair, crop, scale, move, or guess. It validates the locked scene, rotates only `ROOT_Direction`, renders each real direction, restores the scene, and writes `render_manifest.json`.

## Output QA

Run:

```text
python Steamtek_Validate_RenderOutput.py \
  renders/Steamtek_C002/walk \
  metadata/Steamtek_Character_Manifest.json
```

The validator checks dimensions, frame counts, alpha, naming, direction completeness, and baseline stability.

## Godot import

Install the visual/body scenes under `res://scenes/characters/templates/` and the importer under `res://tools/character-pipeline/godot/`. Set the constants at the top of `Steamtek_Import_CharacterFrames.gd`, then run it from the Godot editor. It creates a standard `SpriteFrames` resource with names such as `walk_south` and `walk_north_east`.

Use `Steamtek_CharacterVisual.tscn` for replaceable visuals and `Steamtek_CharacterBodyTemplate.tscn` for the gameplay shell. The visual child owns the `0.73` scale and `(0, -110)` offset; the `CharacterBody2D` remains at scale `1`.

## Approval gate

A character is not production-ready until it has genuine eight-direction renders, stable boot baseline, correct asymmetrical equipment sides, no mirroring, no baked background, the approved rig/actions, matching scale against C001, and an in-Godot Y-sort/collision test.

When running Blender from automation, keep `--python-exit-code 1` so validation failures return a failing process status.
