# Steamtek Off-Axis 60 Camera Pipeline

Status: **locked calibration pipeline**  
Profile: `environment_fixed_off_axis_60_v2`

## Approved camera

- Fixed orthographic 2.5D presentation
- 60 degree horizontal azimuth
- 30 degree elevation
- 0 degree roll
- No runtime camera rotation
- Transparent PNG output
- AgX Medium High Contrast

This profile uses the custom Steamtek parallelogram construction basis. It does
not use the legacy symmetrical 256x128 diamond.

## Safety boundary

The existing C001 character master and its 45-degree camera are preserved as
legacy. This calibration pipeline does not overwrite them. A character may only
move to the new camera after a separate scale, direction, boot-contact, and
Godot integration validation.

## Build the calibration

Run `Build_OffAxis60_Calibration.bat`.

The home-PC Blender path is configured as:

`C:\Program Files\Blender Foundation\Blender 4.5\blender.exe`

On another PC, edit only `BLENDER_EXE` at the top of the batch file. Do not edit
the camera values.

## Output

- `blender/master/Steamtek_OffAxis60_Calibration.blend`
- `output/Steamtek_OffAxis60_Calibration.png`
- `output/Steamtek_OffAxis60_Calibration.json`

The image is a technical proof, not final Steamtek artwork. The construction
axes are a rotated orthogonal pair: front `(1, sqrt(3), 0)` and side
`(-sqrt(3), 1, 0)`. With the locked camera these project directly into Godot's
Y-down pixel coordinates. Amber identifies vertical rise. The asymmetric wall
corner makes accidental mirroring or camera reversal obvious.

## Validate the calibration

Run `Validate_OffAxis60_Calibration.bat` after building. Production rendering
is allowed only when every check prints `PASS` and the final line reads:

`STEAMTEK_CAMERA_CALIBRATION_PASS`

The validator compares Blender's raw measured PNG projection with the exact
Godot snap basis. Both use Y-down coordinates. There is no sign conversion and
no hidden post-render correction.

## Non-negotiable production rules

1. Geometry, origin, alpha silhouette, sockets, and collision stay authoritative.
2. Never rotate a rendered sprite in Godot to fake another camera angle.
3. Never change module root scale from `(1, 1)`.
4. Never independently crop a module after its pivot is generated.
5. AI may enhance materials and surface detail only after geometry validation.
6. The camera and construction basis are locked; models move, the camera does not.
