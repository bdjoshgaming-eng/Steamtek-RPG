# Pipeline QA report

Validated with Blender 4.5.11 LTS and Python on 2026-07-14.

## Passed

- C001 golden-reference hashes match the discovered source files.
- All Python and JSON files parse successfully.
- Master `.blend` contains the four required collections and ten required infrastructure objects.
- Master render output is 1254 x 1254, 100%, PNG RGBA, with transparent film.
- `Camera_Iso` is orthographic at the exact 2:1 dimetric elevation and uses orthographic scale `2.3`.
- Master non-production validation passes with the expected uncalibrated-armature warning.
- Production validation rejects the empty placeholder armature.
- End-to-end temporary dummy test rendered 16 files: two frames in each of eight genuine direction folders.
- Render-output QA passed frame dimensions, alpha, naming, direction order, completeness, and per-direction baseline stability.

## Not executable in this environment

- Godot was not installed on the available command path, so the `.gd` importer and `.tscn` templates were inspected but not launched in Godot. They target Godot 4 syntax and standard resource APIs.

## Required next calibration

Install the actual approved Steamtek humanoid rig (or provide the original C001 `.blend`) and compare a rendered dummy/character in Godot against C001 before declaring the rig and camera framing production-approved. The current master deliberately does not invent those unavailable source values.

