@echo off
setlocal
set "BLENDER_EXE=C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"
set "ROOT=%~dp0"

"%BLENDER_EXE%" --background --factory-startup --python "%ROOT%tools\validate_smv4_w101.py" -- ^
  --metadata "%ROOT%output\SMV4_W101_FrontPlain_HD.json" ^
  --image "%ROOT%output\SMV4_W101_FrontPlain_HD.png" ^
  --godot "%ROOT%godot\SMV4_W101_FrontPlain_HD.tscn"

exit /b %errorlevel%
