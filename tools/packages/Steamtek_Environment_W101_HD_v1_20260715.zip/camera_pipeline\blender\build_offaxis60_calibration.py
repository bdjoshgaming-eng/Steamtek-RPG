"""Build and render the Steamtek fixed off-axis 60-degree calibration scene."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from steamtek_offaxis60_camera import (
    AZIMUTH_DEGREES,
    CAMERA_FORWARD,
    CAMERA_VECTOR,
    ELEVATION_DEGREES,
    FRONT_BAY_STEP,
    FRONT_WORLD_STEP,
    PROFILE_ID,
    ROLL_DEGREES,
    SIDE_BAY_STEP,
    SIDE_WORLD_STEP,
    STOREY_RISE,
    configure_camera,
    configure_render,
)


def arguments():
    argv = sys.argv
    argv = argv[argv.index("--") + 1 :] if "--" in argv else []
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--blend", required=True)
    parser.add_argument("--size", type=int, default=1280)
    return parser.parse_args(argv)


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for datablocks in (
        bpy.data.meshes,
        bpy.data.curves,
        bpy.data.materials,
        bpy.data.cameras,
        bpy.data.lights,
    ):
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)


def material(name, color, metallic=0.0, roughness=0.5, emission=None):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = color
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    if emission:
        bsdf.inputs["Emission Color"].default_value = emission
        bsdf.inputs["Emission Strength"].default_value = 2.0
    return mat


def cube(name, location, scale, mat, collection=None):
    bpy.ops.mesh.primitive_cube_add(location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(mat)
    if collection and obj.name not in collection.objects:
        for owner in list(obj.users_collection):
            owner.objects.unlink(obj)
        collection.objects.link(obj)
    return obj


def point_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def add_area_light(name, location, energy, size, color, target):
    data = bpy.data.lights.new(name, "AREA")
    data.energy = energy
    data.shape = "DISK"
    data.size = size
    data.color = color
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    point_at(obj, target)
    return obj


def pixel(scene, world):
    p = world_to_camera_view(scene, scene.camera, Vector(world))
    return [round(p.x * scene.render.resolution_x, 3), round((1.0 - p.y) * scene.render.resolution_y, 3)]


def image_delta(origin, point):
    """Return a conventional image-space delta (+Y points down)."""
    return [round(point[0] - origin[0], 3), round(point[1] - origin[1], 3)]


def close_pair(measured, expected, tolerance=0.05):
    return all(abs(measured[i] - expected[i]) <= tolerance for i in range(2))


def main():
    args = arguments()
    output = Path(args.output).resolve()
    blend_path = Path(args.blend).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    blend_path.parent.mkdir(parents=True, exist_ok=True)

    clear_scene()
    scene = bpy.context.scene
    configure_render(scene, args.size, args.size, output)

    world = scene.world or bpy.data.worlds.new("SteamtekCalibrationWorld")
    scene.world = world
    world.use_nodes = True
    background = world.node_tree.nodes.get("Background")
    background.inputs["Color"].default_value = (0.004, 0.008, 0.014, 1.0)
    background.inputs["Strength"].default_value = 0.06

    gunmetal = material("M_Gunmetal", (0.025, 0.035, 0.05, 1.0), 0.8, 0.3)
    concrete = material("M_Concrete", (0.055, 0.065, 0.08, 1.0), 0.05, 0.72)
    cyan = material("M_CyanAxis", (0.0, 0.35, 0.46, 1.0), 0.45, 0.25, (0.0, 0.75, 1.0, 1.0))
    magenta = material("M_MagentaAxis", (0.42, 0.01, 0.2, 1.0), 0.45, 0.25, (1.0, 0.02, 0.42, 1.0))
    amber = material("M_AmberVertical", (0.4, 0.16, 0.01, 1.0), 0.55, 0.25, (1.0, 0.3, 0.02, 1.0))

    # A 3x3 ground grid with physical gaps makes projection drift immediately visible.
    for x in (-2.0, 0.0, 2.0):
        for y in (-2.0, 0.0, 2.0):
            cube(f"Floor_{x:+.0f}_{y:+.0f}", (x, y, -0.08), (0.96, 0.96, 0.08), concrete)

    # Locked Steamtek axes: front is +X (cyan), side is -Y (magenta), +Z is amber.
    # The -Y side convention matches the Godot snap contract exactly.
    cube("Axis_X_Cyan", (2.0, -3.2, 0.06), (2.0, 0.055, 0.055), cyan)
    cube("Axis_NegY_Magenta", (-3.2, -2.0, 0.06), (0.055, 2.0, 0.055), magenta)
    cube("Axis_Z_Amber", (-3.2, -3.2, 1.2), (0.065, 0.065, 1.2), amber)

    # An asymmetric L-corner checks handedness and provides a facade/ground proof.
    for i in range(3):
        cube(f"WallFront_{i}", (-2.0 + i * 2.0, 3.05, 1.2), (0.96, 0.10, 1.2), gunmetal)
        cube(f"WallSide_{i}", (3.05, -2.0 + i * 2.0, 1.2), (0.10, 0.96, 1.2), gunmetal)
    cube("FrontMarker_Cyan", (-2.0, 2.91, 1.35), (0.55, 0.035, 0.10), cyan)
    cube("SideMarker_Magenta", (2.91, 0.0, 1.0), (0.035, 0.55, 0.10), magenta)

    camera_data = bpy.data.cameras.new("Camera_Steamtek_OffAxis60")
    camera = bpy.data.objects.new("Camera_Steamtek_OffAxis60", camera_data)
    bpy.context.collection.objects.link(camera)
    target = Vector((0.0, 0.0, 0.8))
    configure_camera(camera, target, args.size)
    scene.camera = camera

    add_area_light("Key", (4.0, -5.0, 8.0), 900.0, 5.0, (0.55, 0.68, 0.82), target)
    add_area_light("Fill", (-4.0, -1.0, 4.5), 260.0, 4.0, (0.12, 0.45, 0.62), target)
    add_area_light("Rim", (-2.0, 4.0, 5.5), 480.0, 3.0, (0.78, 0.20, 0.08), target)

    scene["steamtek_camera_profile"] = PROFILE_ID
    scene["steamtek_camera_locked"] = True
    scene["steamtek_runtime_camera_rotation"] = False
    bpy.context.view_layer.update()

    origin = pixel(scene, (0.0, 0.0, 0.0))
    front_endpoint = pixel(scene, FRONT_WORLD_STEP)
    side_endpoint = pixel(scene, SIDE_WORLD_STEP)
    world_z_1 = pixel(scene, (0.0, 0.0, 1.0))
    measured_front = image_delta(origin, front_endpoint)
    measured_side = image_delta(origin, side_endpoint)
    front_pass = close_pair(measured_front, FRONT_BAY_STEP)
    side_pass = close_pair(measured_side, SIDE_BAY_STEP)
    measured_forward = camera.rotation_euler.to_matrix() @ Vector((0.0, 0.0, -1.0))
    camera_forward_pass = all(abs(measured_forward[i] - CAMERA_FORWARD[i]) <= 0.00001 for i in range(3))
    metadata = {
        "profile": PROFILE_ID,
        "camera_type": "ORTHOGRAPHIC",
        "azimuth_degrees": AZIMUTH_DEGREES,
        "elevation_degrees": ELEVATION_DEGREES,
        "roll_degrees": ROLL_DEGREES,
        "camera_location": [round(v, 6) for v in camera.location],
        "camera_vector_contract": [round(v, 6) for v in CAMERA_VECTOR],
        "camera_forward": [round(v, 6) for v in CAMERA_FORWARD],
        "render_size": [args.size, args.size],
        "transparent": True,
        "runtime_camera_rotation": False,
        "contract_projected_bay_step_front": list(FRONT_BAY_STEP),
        "contract_projected_bay_step_side": list(SIDE_BAY_STEP),
        "contract_storey_rise": list(STOREY_RISE),
        "construction_world_step_front": [round(v, 6) for v in FRONT_WORLD_STEP],
        "construction_world_step_side": [round(v, 6) for v in SIDE_WORLD_STEP],
        "measured_pixels": {
            "origin": origin,
            "front_construction_endpoint": front_endpoint,
            "side_construction_endpoint": side_endpoint,
            "world_z_1": world_z_1,
            "front_image_delta_y_down": measured_front,
            "side_image_delta_y_down": measured_side,
            "vertical_image_delta_y_down": image_delta(origin, world_z_1),
            "front_godot_delta_y_down": measured_front,
            "side_godot_delta_y_down": measured_side
        },
        "contract_validation": {
            "tolerance_pixels": 0.05,
            "front_basis_pass": front_pass,
            "side_basis_pass": side_pass,
            "camera_forward_pass": camera_forward_pass,
            "passed": front_pass and side_pass and camera_forward_pass
        },
        "axis_legend": {
            "front_world_step": [round(v, 6) for v in FRONT_WORLD_STEP],
            "side_world_step": [round(v, 6) for v in SIDE_WORLD_STEP],
            "world_positive_z": "amber"
        }
    }
    output.with_suffix(".json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
    bpy.ops.render.render(write_still=True)
    print(f"WROTE_BLEND {blend_path}")
    print(f"WROTE_RENDER {output}")
    print(f"WROTE_METADATA {output.with_suffix('.json')}")


if __name__ == "__main__":
    main()
