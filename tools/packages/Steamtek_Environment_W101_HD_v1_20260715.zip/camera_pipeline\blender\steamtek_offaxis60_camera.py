"""Locked Steamtek environment camera profile for Blender 4.5+.

This module is deliberately separate from the legacy C001 character camera.
Environment production uses a fixed 60-degree azimuth, 30-degree elevation,
zero-roll orthographic camera and a custom parallelogram construction basis.
"""

from __future__ import annotations

import math

from mathutils import Vector


PROFILE_ID = "environment_fixed_off_axis_60_v2"
CAMERA_TYPE = "ORTHOGRAPHIC"
AZIMUTH_DEGREES = 60.0
ELEVATION_DEGREES = 30.0
ROLL_DEGREES = 0.0
HORIZONTAL_RADIUS = math.sqrt(128.0)
PIXELS_PER_VERTICAL_BU = 181.01933598375618
CAMERA_VECTOR = Vector(
    (
        HORIZONTAL_RADIUS * math.cos(math.radians(AZIMUTH_DEGREES)),
        -HORIZONTAL_RADIUS * math.sin(math.radians(AZIMUTH_DEGREES)),
        HORIZONTAL_RADIUS * math.tan(math.radians(ELEVATION_DEGREES)),
    )
)
CAMERA_FORWARD = (-CAMERA_VECTOR).normalized()
FRONT_BAY_STEP = Vector((313.534, -90.509))
SIDE_BAY_STEP = Vector((-181.020, -156.768))
STOREY_RISE = Vector((0.0, -219.0))

# Production construction axes.  These are an orthogonal two-Blender-unit
# basis rotated 60 degrees in the world XY plane.  With the locked camera they
# project directly into Godot's Y-down pixel coordinates as FRONT_BAY_STEP and
# SIDE_BAY_STEP.  Do not substitute world +X / -Y here: those only matched the
# old validator after a Y-axis convention conversion and did not match PNG
# placement inside Godot.
FRONT_WORLD_STEP = Vector((1.0, math.sqrt(3.0), 0.0))
SIDE_WORLD_STEP = Vector((-math.sqrt(3.0), 1.0, 0.0))


def configure_camera(camera, target, render_height: int):
    """Apply the locked camera without changing model geometry or scale."""
    target = Vector(target)
    camera.location = target + CAMERA_VECTOR
    camera.rotation_euler = (target - camera.location).to_track_quat("-Z", "Y").to_euler()
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = float(render_height) / PIXELS_PER_VERTICAL_BU
    camera["steamtek_profile"] = PROFILE_ID
    camera["steamtek_azimuth_degrees"] = AZIMUTH_DEGREES
    camera["steamtek_elevation_degrees"] = ELEVATION_DEGREES
    camera["steamtek_roll_degrees"] = ROLL_DEGREES
    camera["steamtek_locked"] = True
    return camera


def configure_render(scene, width: int, height: int, output_path=None):
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x = width
    scene.render.resolution_y = height
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.image_settings.color_depth = "8"
    scene.render.image_settings.compression = 15
    scene.render.film_transparent = True
    scene.render.use_file_extension = True
    scene.view_settings.look = "AgX - Medium High Contrast"
    if output_path is not None:
        scene.render.filepath = str(output_path)
