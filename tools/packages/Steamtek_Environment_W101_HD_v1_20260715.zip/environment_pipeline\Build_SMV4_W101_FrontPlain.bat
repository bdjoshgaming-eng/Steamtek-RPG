@echo off
setlocal
set "BLENDER_EXE=C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"
set "ROOT=%~dp0"

"%BLENDER_EXE%" --background --factory-startup --python "%ROOT%blender\build_smv4_w101_front_plain.py" -- ^
  --output "%ROOT%output\SMV4_W101_FrontPlain_HD.png" ^
  --metadata "%ROOT%output\SMV4_W101_FrontPlain_HD.json" ^
  --blend "%ROOT%blender\master\SMV4_W101_FrontPlain_HD.blend" ^
  --godot "%ROOT%godot\SMV4_W101_FrontPlain_HD.tscn"

if errorlevel 1 exit /b %errorlevel%
call "%ROOT%Validate_SMV4_W101_FrontPlain.bat"
