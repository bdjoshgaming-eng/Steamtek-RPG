bl_info = {
    "name": "Steamtek Humanoid Intake",
    "author": "Steamtek Studio",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "3D View > Sidebar > Steamtek",
    "description": "Meshy-to-Blender-to-Godot humanoid intake and equipment QA",
    "category": "Import-Export",
}

import bpy
import json
import os
from pathlib import Path
from bpy.props import PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup


ANIMATION_ALIASES = {
    "idle": "STK_IDLE",
    "walk": "STK_WALK",
    "walking": "STK_WALK",
    "run": "STK_RUN",
    "running": "STK_RUN",
    "attack": "STK_ATTACK",
    "melee": "STK_ATTACK_MELEE",
    "pistol": "STK_ATTACK_PISTOL",
    "rifle": "STK_ATTACK_RIFLE",
    "shoot": "STK_ATTACK_PISTOL",
    "cast": "STK_CAST",
    "jump": "STK_JUMP",
    "hit": "STK_HURT",
    "hurt": "STK_HURT",
    "death": "STK_DEATH",
    "die": "STK_DEATH",
}


def _animation_contract_name(action_name):
    """Map Meshy/Mixamo-style names without destroying unknown clips."""
    lower = action_name.lower().replace("-", "_").replace(" ", "_")
    # Specific combat aliases must win over the generic word "attack".
    priority = (
        "pistol", "rifle", "melee", "shoot", "walking", "running",
        "attack", "idle", "walk", "run", "cast", "jump", "hurt",
        "hit", "death", "die",
    )
    for alias in priority:
        if alias in lower:
            return ANIMATION_ALIASES[alias]
    return ""

BONE_ALIASES = {
    "hips": ("hips", "pelvis", "mixamorig:hips", "root"),
    "spine": ("spine", "mixamorig:spine"),
    "chest": ("chest", "spine1", "spine2", "mixamorig:spine1", "mixamorig:spine2"),
    "neck": ("neck", "mixamorig:neck"),
    "head": ("head", "mixamorig:head"),
    "hand.L": ("hand.l", "lefthand", "mixamorig:lefthand"),
    "hand.R": ("hand.r", "righthand", "mixamorig:righthand"),
    "foot.L": ("foot.l", "leftfoot", "mixamorig:leftfoot"),
    "foot.R": ("foot.r", "rightfoot", "mixamorig:rightfoot"),
}


def _find_armatures():
    return [obj for obj in bpy.context.scene.objects if obj.type == "ARMATURE"]


def _find_skinned_meshes():
    result = []
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH":
            continue
        if any(mod.type == "ARMATURE" for mod in obj.modifiers):
            result.append(obj)
    return result


def _active_armature(context):
    armature = context.scene.steamtek_humanoid.armature
    if armature and armature.type == "ARMATURE":
        return armature
    armatures = _find_armatures()
    return armatures[0] if len(armatures) == 1 else None


def _bone_lookup(armature):
    return {bone.name.lower(): bone.name for bone in armature.data.bones}


def _semantic_bone(armature, semantic):
    lookup = _bone_lookup(armature)
    for alias in BONE_ALIASES.get(semantic, (semantic,)):
        if alias.lower() in lookup:
            return lookup[alias.lower()]
        for normalized_name, original_name in lookup.items():
            if normalized_name.rsplit(":", 1)[-1] == alias.lower():
                return original_name
    return ""


def _scene_report():
    armatures = _find_armatures()
    meshes = [obj for obj in bpy.context.scene.objects if obj.type == "MESH"]
    skinned = _find_skinned_meshes()
    actions = list(bpy.data.actions)
    report = {
        "schema": "SteamtekHumanoidIntakeReport-1",
        "blend_file": bpy.data.filepath,
        "armatures": [],
        "meshes": [],
        "animations": [],
        "errors": [],
        "warnings": [],
    }
    if not armatures:
        report["errors"].append("No armature found")
    if len(armatures) > 1:
        report["warnings"].append("Multiple armatures found; choose the canonical armature explicitly")
    if not skinned:
        report["errors"].append("No mesh with an Armature modifier found")

    for armature in armatures:
        semantic = {key: _semantic_bone(armature, key) for key in BONE_ALIASES}
        missing = [key for key, value in semantic.items() if not value]
        report["armatures"].append({
            "name": armature.name,
            "bone_count": len(armature.data.bones),
            "semantic_bones": semantic,
            "missing_semantics": missing,
            "scale": list(armature.scale),
        })
        if missing:
            report["warnings"].append(f"{armature.name}: missing semantic bones {missing}")

    for mesh in meshes:
        armature_modifiers = [mod for mod in mesh.modifiers if mod.type == "ARMATURE"]
        report["meshes"].append({
            "name": mesh.name,
            "vertices": len(mesh.data.vertices),
            "polygons": len(mesh.data.polygons),
            "materials": len(mesh.material_slots),
            "vertex_groups": len(mesh.vertex_groups),
            "armatures": [mod.object.name if mod.object else "" for mod in armature_modifiers],
            "scale": list(mesh.scale),
        })
        if armature_modifiers and not mesh.vertex_groups:
            report["errors"].append(f"{mesh.name}: Armature modifier exists but no vertex groups exist")

    for action in actions:
        report["animations"].append({
            "name": action.name,
            "frame_start": action.frame_range[0],
            "frame_end": action.frame_range[1],
        })
    if not actions:
        report["warnings"].append("No animation actions found; export will be static")
    report["passed"] = not report["errors"]
    return report


class SteamtekHumanoidSettings(PropertyGroup):
    source_file: StringProperty(name="Meshy Character / Animation File", subtype="FILE_PATH")
    export_file: StringProperty(name="Godot GLB Output", subtype="FILE_PATH", default="//exports/Steamtek_Humanoid.glb")
    armature: PointerProperty(name="Canonical Armature", type=bpy.types.Object)


class STK_OT_import_meshy(Operator):
    bl_idname = "steamtek.import_meshy"
    bl_label = "Import Meshy GLB/FBX"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        path = bpy.path.abspath(context.scene.steamtek_humanoid.source_file)
        if not os.path.isfile(path):
            self.report({"ERROR"}, "Choose an existing GLB, GLTF, or FBX file")
            return {"CANCELLED"}
        suffix = Path(path).suffix.lower()
        before = set(bpy.context.scene.objects)
        if suffix in {".glb", ".gltf"}:
            bpy.ops.import_scene.gltf(filepath=path)
        elif suffix == ".fbx":
            bpy.ops.import_scene.fbx(filepath=path)
        else:
            self.report({"ERROR"}, "Supported files: GLB, GLTF, FBX")
            return {"CANCELLED"}
        imported = [obj for obj in bpy.context.scene.objects if obj not in before]
        armatures = [obj for obj in imported if obj.type == "ARMATURE"]
        if len(armatures) == 1:
            context.scene.steamtek_humanoid.armature = armatures[0]
        self.report({"INFO"}, f"Imported {len(imported)} objects; preserved {len(bpy.data.actions)} actions")
        return {"FINISHED"}


class STK_OT_audit(Operator):
    bl_idname = "steamtek.audit_humanoid"
    bl_label = "Audit Character"

    def execute(self, context):
        report = _scene_report()
        context.scene["steamtek_last_audit"] = json.dumps(report)
        level = {"INFO"} if report["passed"] else {"WARNING"}
        self.report(level, f"Audit: {len(report['errors'])} errors, {len(report['warnings'])} warnings")
        print(json.dumps(report, indent=2))
        return {"FINISHED"}


class STK_OT_normalize_animations(Operator):
    bl_idname = "steamtek.normalize_animations"
    bl_label = "Normalize Animation Names"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        changed = 0
        occupied = {action.name for action in bpy.data.actions}
        for action in bpy.data.actions:
            target = _animation_contract_name(action.name)
            if not target or action.name == target:
                continue
            if target in occupied:
                target = f"{target}_{changed + 2:02d}"
            occupied.add(target)
            action.name = target
            changed += 1
        self.report({"INFO"}, f"Normalized {changed} animation names")
        return {"FINISHED"}


def _create_socket(armature, socket_name, semantic_bone):
    bone_name = _semantic_bone(armature, semantic_bone)
    if not bone_name:
        return False
    existing = bpy.data.objects.get(socket_name)
    if existing:
        return True
    empty = bpy.data.objects.new(socket_name, None)
    bpy.context.collection.objects.link(empty)
    empty.empty_display_type = "ARROWS"
    empty.empty_display_size = 0.12
    empty.parent = armature
    empty.parent_type = "BONE"
    empty.parent_bone = bone_name
    empty.matrix_parent_inverse = armature.matrix_world.inverted()
    empty["steamtek_socket"] = True
    return True


class STK_OT_create_sockets(Operator):
    bl_idname = "steamtek.create_sockets"
    bl_label = "Create Equipment Sockets"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = _active_armature(context)
        if not armature:
            self.report({"ERROR"}, "Choose a canonical armature")
            return {"CANCELLED"}
        socket_map = {
            "SOCKET_Head": "head",
            "SOCKET_Hand_R": "hand.R",
            "SOCKET_Hand_L": "hand.L",
            "SOCKET_Back": "chest",
        }
        made = sum(1 for name, semantic in socket_map.items() if _create_socket(armature, name, semantic))
        self.report({"INFO"}, f"Created or confirmed {made}/{len(socket_map)} sockets")
        return {"FINISHED"}


class STK_OT_bind_clothing(Operator):
    bl_idname = "steamtek.bind_clothing"
    bl_label = "Bind Selected Clothing to Canonical Rig"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = _active_armature(context)
        body = context.view_layer.objects.active
        clothing = [obj for obj in context.selected_objects if obj.type == "MESH" and obj != body]
        if not armature or not body or body.type != "MESH" or not clothing:
            self.report({"ERROR"}, "Select clothing first, fitted body mesh last, and choose the canonical armature")
            return {"CANCELLED"}
        for item in clothing:
            item.vertex_groups.clear()
            transfer = item.modifiers.new("STK_TransferBodyWeights", "DATA_TRANSFER")
            transfer.object = body
            transfer.use_vert_data = True
            transfer.data_types_verts = {"VGROUP_WEIGHTS"}
            transfer.vert_mapping = "POLYINTERP_NEAREST"
            context.view_layer.objects.active = item
            bpy.ops.object.modifier_apply(modifier=transfer.name)
            arm_mod = next((m for m in item.modifiers if m.type == "ARMATURE"), None)
            if not arm_mod:
                arm_mod = item.modifiers.new("Armature", "ARMATURE")
            arm_mod.object = armature
            item.parent = armature
            item["steamtek_equipment_mode"] = "skinned"
        context.view_layer.objects.active = body
        self.report({"INFO"}, f"Bound {len(clothing)} clothing meshes; deformation QA is still required")
        return {"FINISHED"}


class STK_OT_export_godot(Operator):
    bl_idname = "steamtek.export_godot"
    bl_label = "Export Godot GLB + Report"

    def execute(self, context):
        output = Path(bpy.path.abspath(context.scene.steamtek_humanoid.export_file))
        if output.suffix.lower() != ".glb":
            output = output.with_suffix(".glb")
        output.parent.mkdir(parents=True, exist_ok=True)
        report = _scene_report()
        report_path = output.with_suffix(".intake.json")
        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        if not report["passed"]:
            self.report({"ERROR"}, f"Audit failed. Read {report_path.name}")
            return {"CANCELLED"}
        bpy.ops.export_scene.gltf(
            filepath=str(output),
            export_format="GLB",
            export_animations=True,
            export_skins=True,
            export_morph=True,
            export_yup=True,
            export_apply=False,
        )
        self.report({"INFO"}, f"Exported {output.name} with {len(bpy.data.actions)} animation actions")
        return {"FINISHED"}


class STK_PT_humanoid_intake(Panel):
    bl_label = "Humanoid Intake"
    bl_idname = "STK_PT_humanoid_intake"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Steamtek"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.steamtek_humanoid
        layout.prop(settings, "source_file")
        layout.operator("steamtek.import_meshy", icon="IMPORT")
        layout.separator()
        layout.prop(settings, "armature")
        layout.operator("steamtek.audit_humanoid", icon="CHECKMARK")
        layout.operator("steamtek.normalize_animations", icon="ACTION")
        layout.operator("steamtek.create_sockets", icon="EMPTY_ARROWS")
        layout.separator()
        layout.label(text="Clothing: select pieces, body last")
        layout.operator("steamtek.bind_clothing", icon="MOD_DATA_TRANSFER")
        layout.separator()
        layout.prop(settings, "export_file")
        layout.operator("steamtek.export_godot", icon="EXPORT")


CLASSES = (
    SteamtekHumanoidSettings,
    STK_OT_import_meshy,
    STK_OT_audit,
    STK_OT_normalize_animations,
    STK_OT_create_sockets,
    STK_OT_bind_clothing,
    STK_OT_export_godot,
    STK_PT_humanoid_intake,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.steamtek_humanoid = PointerProperty(type=SteamtekHumanoidSettings)


def unregister():
    del bpy.types.Scene.steamtek_humanoid
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
