@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%tools\Install-SteamtekHumanoidPipeline.ps1" -ProjectRoot "C:\My Game\Steamtek-RPG" -BlenderRoot "C:\Program Files\Blender Foundation\Blender 4.5"
if errorlevel 1 (
  echo.
  echo Installation failed. Review the message above.
  pause
  exit /b 1
)
echo.
echo Installation complete. Restart Blender and Godot if they are open.
pause
