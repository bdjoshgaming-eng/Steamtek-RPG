param(
    [string]$ProjectRoot = "C:\My Game\Steamtek-RPG",
    [string]$BlenderRoot = "C:\Program Files\Blender Foundation\Blender 4.5"
)

$ErrorActionPreference = "Stop"
$PipelineRoot = Split-Path -Parent $PSScriptRoot
$BlenderExe = Join-Path $BlenderRoot "blender.exe"
$BlenderAddonSource = Join-Path $PipelineRoot "blender_addon\steamtek_humanoid_intake"
$BlenderAddonTarget = Join-Path $env:APPDATA "Blender Foundation\Blender\4.5\scripts\addons\steamtek_humanoid_intake"
$GodotAddonSource = Join-Path $PipelineRoot "godot\addons\steamtek_humanoid_runtime"
$GodotAddonTarget = Join-Path $ProjectRoot "addons\steamtek_humanoid_runtime"
$TemplateSource = Join-Path $PipelineRoot "godot\templates\SteamtekModularHumanoid3D.tscn"
$TemplateTarget = Join-Path $ProjectRoot "scenes\characters\templates\SteamtekModularHumanoid3D.tscn"
$ItemTemplateSource = Join-Path $PipelineRoot "godot\templates\SteamtekEquipmentItemTemplate.tres"
$ItemTemplateTarget = Join-Path $ProjectRoot "resources\equipment\SteamtekEquipmentItemTemplate.tres"
$ToolsTarget = Join-Path $ProjectRoot "tools\steamtek-humanoid-pipeline"
$BackupTarget = Join-Path $ToolsTarget "backups"
$QaTarget = Join-Path $ToolsTarget "qa"
$MeshyPlugin = Join-Path $ProjectRoot "addons\meshy-godot-plugin"

if (-not (Test-Path -LiteralPath $ProjectRoot)) {
    throw "Godot project folder was not found: $ProjectRoot"
}
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "project.godot"))) {
    throw "project.godot was not found in: $ProjectRoot"
}
if (-not (Test-Path -LiteralPath $BlenderExe)) {
    throw "Blender 4.5 was not found: $BlenderExe"
}

Write-Host "Installing Steamtek Humanoid Pipeline..." -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $MeshyPlugin)) {
    Write-Warning "Meshy Godot plug-in was not found at $MeshyPlugin. The Steamtek pipeline will still install."
} else {
    Write-Host "Meshy Godot plug-in detected and will be preserved." -ForegroundColor Green
}

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $BlenderAddonTarget) | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $TemplateTarget) | Out-Null
New-Item -ItemType Directory -Force -Path $ToolsTarget | Out-Null
New-Item -ItemType Directory -Force -Path $BackupTarget | Out-Null
New-Item -ItemType Directory -Force -Path $QaTarget | Out-Null

$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$ProjectFile = Join-Path $ProjectRoot "project.godot"
Copy-Item -LiteralPath $ProjectFile -Destination (Join-Path $BackupTarget "project-$Timestamp.godot") -Force
if (Test-Path -LiteralPath $GodotAddonTarget) {
    Copy-Item -LiteralPath $GodotAddonTarget -Destination (Join-Path $BackupTarget "steamtek_humanoid_runtime-$Timestamp") -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $GodotAddonTarget | Out-Null
Copy-Item -LiteralPath $BlenderAddonSource -Destination (Split-Path -Parent $BlenderAddonTarget) -Recurse -Force
Copy-Item -Path (Join-Path $GodotAddonSource "*") -Destination $GodotAddonTarget -Recurse -Force
Copy-Item -LiteralPath $TemplateSource -Destination $TemplateTarget -Force
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $ItemTemplateTarget) | Out-Null
Copy-Item -LiteralPath $ItemTemplateSource -Destination $ItemTemplateTarget -Force
Copy-Item -LiteralPath (Join-Path $PipelineRoot "config\steamtek_humanoid_standard.json") -Destination $ToolsTarget -Force
Copy-Item -LiteralPath (Join-Path $PipelineRoot "README.md") -Destination (Join-Path $ToolsTarget "README.md") -Force
Copy-Item -LiteralPath (Join-Path $PipelineRoot "MESHY_TO_STEAMTEK_QUICKSTART.md") -Destination $ToolsTarget -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "process_meshy_character.py") -Destination $ToolsTarget -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "Invoke-SteamtekCharacterIntake.ps1") -Destination $ToolsTarget -Force
Copy-Item -LiteralPath (Join-Path $PipelineRoot "Run_Meshy_Character_Intake.bat") -Destination (Join-Path $ProjectRoot "tools\Run_Meshy_Character_Intake.bat") -Force

$ContentFolders = @(
    "assets\characters\humanoid\incoming",
    "assets\characters\humanoid\base",
    "assets\characters\humanoid\blender",
    "assets\characters\humanoid\animations",
    "assets\characters\humanoid\equipment\head",
    "assets\characters\humanoid\equipment\torso",
    "assets\characters\humanoid\equipment\legs",
    "assets\characters\humanoid\equipment\feet",
    "assets\characters\humanoid\equipment\hands",
    "assets\characters\humanoid\equipment\weapon_main",
    "assets\characters\humanoid\equipment\weapon_off",
    "assets\characters\humanoid\equipment\back",
    "scenes\characters\humanoid",
    "resources\equipment"
)
foreach ($RelativeFolder in $ContentFolders) {
    New-Item -ItemType Directory -Force -Path (Join-Path $ProjectRoot $RelativeFolder) | Out-Null
}

& $BlenderExe --background --python (Join-Path $PSScriptRoot "enable_blender_addon.py")
if ($LASTEXITCODE -ne 0) {
    throw "Blender could not enable the Steamtek Humanoid Intake add-on."
}

$ProjectText = Get-Content -LiteralPath $ProjectFile -Raw
$PluginPath = "res://addons/steamtek_humanoid_runtime/plugin.cfg"
if ($ProjectText -notmatch [regex]::Escape($PluginPath)) {
    if ($ProjectText -match '(?ms)^\[editor_plugins\]\s*\r?\nenabled=PackedStringArray\((.*?)\)') {
        $Existing = $Matches[1].Trim()
        $NewList = if ($Existing) { "$Existing, `"$PluginPath`"" } else { "`"$PluginPath`"" }
        $ProjectText = [regex]::Replace(
            $ProjectText,
            '(?ms)^\[editor_plugins\]\s*\r?\nenabled=PackedStringArray\((.*?)\)',
            "[editor_plugins]`r`nenabled=PackedStringArray($NewList)",
            1
        )
    } else {
        $ProjectText = $ProjectText.TrimEnd() + "`r`n`r`n[editor_plugins]`r`nenabled=PackedStringArray(`"$PluginPath`")`r`n"
    }
    Set-Content -LiteralPath $ProjectFile -Value $ProjectText -Encoding utf8
}

Write-Host "" 
Write-Host "Steamtek Humanoid Pipeline installed." -ForegroundColor Green
Write-Host "Meshy plug-in preserved: $(Join-Path $ProjectRoot 'addons\meshy-godot-plugin')"
Write-Host "Godot runtime: $GodotAddonTarget"
Write-Host "Godot template: $TemplateTarget"
Write-Host "Blender panel: 3D View > N sidebar > Steamtek"
