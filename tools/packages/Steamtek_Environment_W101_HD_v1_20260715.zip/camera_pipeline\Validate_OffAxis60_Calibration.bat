@echo off
setlocal
set "ROOT=%~dp0"
set "BLENDER_EXE=C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"

if not exist "%BLENDER_EXE%" (
  echo Blender was not found at:
  echo %BLENDER_EXE%
  echo.
  echo Edit BLENDER_EXE in this file for this PC, then run it again.
  pause
  exit /b 1
)

"%BLENDER_EXE%" --background --factory-startup --python "%ROOT%tools\validate_offaxis60_calibration.py" -- --metadata "%ROOT%output\Steamtek_OffAxis60_Calibration.json" --image "%ROOT%output\Steamtek_OffAxis60_Calibration.png"
if errorlevel 1 (
  echo.
  echo Calibration validation failed. Do not use this camera for production renders.
  pause
  exit /b 1
)

echo.
echo Calibration validation passed. The 60-degree camera contract is production-safe.
pause
