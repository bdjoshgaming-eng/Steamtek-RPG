# Pipeline QA report

Validated with Blender 4.5.11 LTS and Python on 2026-07-14.

## Passed

- C001 golden-reference hashes match the discovered source files.
- All Python and JSON files parse successfully.
- Master `.blend` contains the four required collections and ten required infrastructure objects.
- Master render output is 1254 x 1254, 100%, PNG RGBA, with transparent film.
- `Camera_Iso` is orthographic at the exact 2:1 dimetric elevation and uses orthographic scale `2.3`.
- Master non-production validation passes with the expected uncalibrated-armature warning.
- Production validation rejects the empty placeholder armature.
- End-to-end temporary dummy test rendered 16 files: two frames in each of eight genuine direction folders.
- Render-output QA passed frame dimensions, alpha, naming, direction order, completeness, and per-direction baseline stability.
- Blender 4.5's bundled Rigify human metarig generated successfully as `Steamtek_HumanRig_v1`.
- Generated candidate contains 706 production/control bones and retains the editable 159-bone metarig.
- Rig and metarig are parented to `ROOT_GroundContact` at location/rotation zero and scale one.
- Locked `Camera_Iso`, 1254 x 1254 canvas, and transparent render settings remain unchanged after rig generation.
- Non-production scene validation passes; production validation correctly rejects the candidate until its status becomes `approved`.
- `STK_CalibrationDummy_v1` binds 34 modular mesh parts to the generated Rigify deform bones.
- `STK_IDLE` and `STK_WALK` contain eight frames each and render through all eight genuine direction rotations.
- Full calibration output passed raw QA: 128 transparent 1254 x 1254 PNGs across idle and walk.
- Full calibration output passed production QA: 128 fixed 256 x 256 PNGs across idle and walk, uniformly resized without crop or recentering.
- A combined Godot 4 `SpriteFrames` resource and C001 comparison scene were generated with the locked `0.73` visual scale and `(0, -110)` offset.

## Not executable in this environment

- Godot was not installed on the available command path, so the generated `.tres`, `.tscn`, and importer were structurally inspected but not launched. They target Godot 4 syntax and standard resource APIs.

## Required next calibration

Open `STK_CharacterPipelineCalibration.tscn` in Godot and compare the calibration dummy against C001 before declaring the rig and camera framing production-approved. If an authoritative original C001 `.blend` becomes available, use it to recalibrate or replace the candidate rather than preserving conflicting assumptions.
