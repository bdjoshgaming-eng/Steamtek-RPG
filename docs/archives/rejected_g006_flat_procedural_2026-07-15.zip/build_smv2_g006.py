"""Build the staging-only G006 rain-wet sidewalk slab tile."""

from __future__ import annotations

import sys
from pathlib import Path

import bpy

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_smv2_g001 import add_irregular_surface, add_tar_crack, configure_scene
from build_smv2_w003 import clear_scene


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ASSET_NAME = "SMV2_G006_RainWetSidewalkSlab"
BLEND_PATH = PROJECT_ROOT / f"blender/modular_v2/{ASSET_NAME}.blend"
RENDER_PATH = PROJECT_ROOT / (
    "assets/modular_v2/ground/source/blender_renders/"
    f"{ASSET_NAME}_blender_raw.png"
)


def sidewalk_material(name, low, high, wet_bias=0.0):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    shader = nodes.new("ShaderNodeBsdfPrincipled")

    color_noise = nodes.new("ShaderNodeTexNoise")
    color_noise.name = "FineWarmConcreteVariation"
    color_noise.inputs["Scale"].default_value = 48.0
    color_noise.inputs["Detail"].default_value = 6.0
    color_noise.inputs["Roughness"].default_value = 0.78
    color_noise.inputs["Distortion"].default_value = 0.10
    color_ramp = nodes.new("ShaderNodeValToRGB")
    color_ramp.name = "WarmRainConcreteRange"
    color_ramp.color_ramp.elements[0].position = 0.18
    color_ramp.color_ramp.elements[0].color = (*low, 1.0)
    color_ramp.color_ramp.elements[1].position = 0.84
    color_ramp.color_ramp.elements[1].color = (*high, 1.0)

    cool_cast = nodes.new("ShaderNodeTexNoise")
    cool_cast.name = "SoftRainColorCast"
    cool_cast.inputs["Scale"].default_value = 8.0
    cool_cast.inputs["Detail"].default_value = 3.0
    cool_cast.inputs["Roughness"].default_value = 0.65
    cool_ramp = nodes.new("ShaderNodeValToRGB")
    cool_ramp.name = "CoolWarmRainBalance"
    cool_ramp.color_ramp.elements[0].color = (0.025, 0.050, 0.055, 1.0)
    cool_ramp.color_ramp.elements[1].color = (0.090, 0.055, 0.026, 1.0)
    color_mix = nodes.new("ShaderNodeMixRGB")
    color_mix.blend_type = "SOFT_LIGHT"
    color_mix.inputs["Fac"].default_value = 0.12

    wetness = nodes.new("ShaderNodeTexNoise")
    wetness.name = "SidewalkWaterFilm"
    wetness.inputs["Scale"].default_value = 6.0
    wetness.inputs["Detail"].default_value = 4.5
    wetness.inputs["Roughness"].default_value = 0.72
    wetness.inputs["Distortion"].default_value = 0.25
    roughness_ramp = nodes.new("ShaderNodeValToRGB")
    roughness_ramp.name = "SidewalkWetDryRoughness"
    roughness_ramp.color_ramp.elements[0].position = 0.28
    roughness_ramp.color_ramp.elements[0].color = (
        0.20 + wet_bias, 0.20 + wet_bias, 0.20 + wet_bias, 1.0
    )
    roughness_ramp.color_ramp.elements[1].position = 0.74
    roughness_ramp.color_ramp.elements[1].color = (0.68, 0.68, 0.68, 1.0)

    aggregate = nodes.new("ShaderNodeTexNoise")
    aggregate.name = "SidewalkFineAggregate"
    aggregate.inputs["Scale"].default_value = 125.0
    aggregate.inputs["Detail"].default_value = 5.0
    aggregate.inputs["Roughness"].default_value = 0.82
    bump = nodes.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = 0.16
    bump.inputs["Distance"].default_value = 0.009

    links.new(color_noise.outputs["Fac"], color_ramp.inputs["Fac"])
    links.new(cool_cast.outputs["Fac"], cool_ramp.inputs["Fac"])
    links.new(color_ramp.outputs["Color"], color_mix.inputs[1])
    links.new(cool_ramp.outputs["Color"], color_mix.inputs[2])
    links.new(color_mix.outputs["Color"], shader.inputs["Base Color"])
    links.new(wetness.outputs["Fac"], roughness_ramp.inputs["Fac"])
    links.new(roughness_ramp.outputs["Color"], shader.inputs["Roughness"])
    links.new(aggregate.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], shader.inputs["Normal"])
    links.new(shader.outputs["BSDF"], output.inputs["Surface"])
    shader.inputs["Metallic"].default_value = 0.0
    if "Coat Weight" in shader.inputs:
        shader.inputs["Coat Weight"].default_value = 0.10
        shader.inputs["Coat Roughness"].default_value = 0.28
    return material


def joint_material():
    material = bpy.data.materials.new("STK_WetSidewalkExpansionJoint")
    material.diffuse_color = (0.006, 0.008, 0.009, 1.0)
    material.use_nodes = True
    shader = material.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = material.diffuse_color
    shader.inputs["Roughness"].default_value = 0.82
    return material


def add_slab_panel(name, center, size, z, mat):
    """Add one shallow poured-concrete panel with manufactured bevels."""
    bpy.ops.mesh.primitive_cube_add(location=(center[0], center[1], z))
    panel = bpy.context.object
    panel.name = name
    panel.dimensions = (size[0], size[1], 0.080)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    panel.data.materials.append(mat)

    bevel = panel.modifiers.new(name="EdgeWearBevel", type="BEVEL")
    bevel.width = 0.035
    bevel.segments = 3
    bevel.limit_method = "ANGLE"
    return panel


def build_g006():
    # Four related pours avoid a perfectly repeated checkerboard while keeping
    # the sidewalk quieter and warmer than the blue-black traffic surface.
    slabs = (
        sidewalk_material(
            "STK_SidewalkPour_A", (0.038, 0.036, 0.036), (0.180, 0.145, 0.118), -0.01
        ),
        sidewalk_material(
            "STK_SidewalkPour_B", (0.032, 0.034, 0.036), (0.154, 0.140, 0.126), 0.01
        ),
        sidewalk_material(
            "STK_SidewalkPour_C", (0.042, 0.038, 0.035), (0.194, 0.153, 0.116), 0.00
        ),
        sidewalk_material(
            "STK_SidewalkPour_D", (0.035, 0.035, 0.037), (0.164, 0.145, 0.132), -0.02
        ),
    )
    joint = joint_material()

    # A full-footprint recessed bed guarantees a continuous exact diamond once
    # the canonical alpha is reapplied. It also supplies the dark expansion
    # joints between the individually modeled slabs.
    add_irregular_surface(
        "ExpansionJointBed", (0, 0),
        ((-2.0, -2.0), (2.0, -2.0), (2.0, 2.0), (-2.0, 2.0)), joint, z=-0.044,
    )

    panel_size = (1.955, 1.955)
    add_slab_panel("SidewalkPanel_NW", (-1.0, 1.0), panel_size, -0.004, slabs[0])
    add_slab_panel("SidewalkPanel_NE", (1.0, 1.0), panel_size, 0.002, slabs[1])
    add_slab_panel("SidewalkPanel_SW", (-1.0, -1.0), panel_size, 0.000, slabs[2])
    add_slab_panel("SidewalkPanel_SE", (1.0, -1.0), panel_size, -0.002, slabs[3])

    # Two hairline filled cracks provide controlled local wear without turning
    # every panel into the same damaged stamp.
    add_tar_crack(
        "FilledHairline_A", ((-1.72, 1.43), (-1.42, 1.20), (-1.19, 0.86)),
        joint, width=0.0045, z=0.043,
    )
    add_tar_crack(
        "FilledHairline_B", ((0.52, -1.54), (0.76, -1.28), (0.70, -0.94)),
        joint, width=0.004, z=0.043,
    )


def main():
    BLEND_PATH.parent.mkdir(parents=True, exist_ok=True)
    RENDER_PATH.parent.mkdir(parents=True, exist_ok=True)
    clear_scene()
    build_g006()
    configure_scene(RENDER_PATH)
    bpy.ops.wm.save_as_mainfile(filepath=str(BLEND_PATH))
    bpy.ops.render.render(write_still=True)
    print(f"Saved blend: {BLEND_PATH}")
    print(f"Rendered PNG: {RENDER_PATH}")


if __name__ == "__main__":
    main()
