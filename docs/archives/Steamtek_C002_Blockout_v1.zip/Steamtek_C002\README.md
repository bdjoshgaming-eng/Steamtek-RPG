# Steamtek_C002

Steamtek_C002 is the first production character built through the approved reusable Steamtek character pipeline.

## Identity

- Role: maintenance worker NPC / industrial pressure-system technician
- Visual tier: production NPC, intentionally simpler than hero benchmark Steamtek_C001
- Rig: approved `Steamtek_HumanRig_v1`
- Source forward axis: Blender `-Y`
- Required actions: `STK_IDLE`, `STK_WALK`

## Locked concept

`concept/Steamtek_C002_Turnaround_v1.png` is the approved visual target. The left copper pressure-tool gauntlet, right-hip diagnostic unit and wrench holster, back regulator assembly, cyan diagnostics, and orange safety accents must remain on their physical sides in every rendered direction.

The concept controls identity, silhouette, materials, and equipment placement. The approved master controls camera, scale, roots, rig, animation names, canvas, direction order, and Godot transforms.

## Rigged blockout v1

`blender/Steamtek_C002_Blockout_v1.blend` contains 58 deform-bound modular parts on the approved rig, plus inherited `STK_IDLE` and `STK_WALK` actions. It passed production scene validation and a genuine eight-direction idle preview.

The blockout establishes the fitted silhouette and locked equipment sides. It is deliberately not the final detailed mesh.

## Next production step

Approve the eight-direction blockout, then replace blockout masses with detailed modeled jacket, respirator, gauntlet, tools, regulator pack, and production materials without changing the approved rig, roots, framing, or equipment sides.
